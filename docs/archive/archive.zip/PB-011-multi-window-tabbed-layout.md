---
id: PB-011
title: Multi-window tabbed layout with one plot per tab
summary: The top-level layout uses simultaneous windows, multiple tabs per window, and exactly one plot per tab
date: 2026-11-11
status: accepted
layers: [architecture]
state: 02-architecture/components/window-and-plot.md
artifacts:
  - src/app/windows/workspace.cpp
supersedes: []
superseded_by: []
related: []
---

# PB-011: Multi-window tabbed layout with one plot per tab

## Context
Users want separate analysis contexts visible at the same time, such as one window per scenario or comparison task, each with its own selection.

## Decision
The top-level analysis layout uses multiple simultaneous windows, each with multiple tabs, and each tab contains exactly one plot.

## Rationale
Separate windows and tabs give each analysis context its own surface and selection while keeping one plot per tab unambiguous.

## Alternatives Considered
- A single window with a docked plot grid
- One plot per window with no tabs

## Consequences
- Positive: clear analysis contexts, per-tab isolation, one plot per tab.
- Negative: multi-window state management must stay isolated from the series model.

## Verification
Layout integration coverage checks windows, tabs, and one-plot-per-tab (`INFO-038`); the layout use case is `UC-005`.

## Review Trigger
None.