---
id: PB-003
title: Dear ImGui, ImPlot, and GLFW UI foundation
summary: Dear ImGui, ImPlot, and GLFW are the UI and plotting foundation
date: 2026-11-11
status: accepted
layers: [architecture]
state: 02-architecture/components/ui-shell.md
artifacts:
  - src/ui/backend/imgui_backend.hpp
  - src/ui/backend/imgui_backend.cpp
supersedes: []
superseded_by: []
related: []
---

# PB-003: Dear ImGui, ImPlot, and GLFW UI foundation

## Context
The viewer needs a native desktop UI with a multi-window, multi-tab plotting workspace, low dependency footprint, and predictable behavior on Linux.

## Decision
Dear ImGui, ImPlot, and GLFW are the UI and plotting foundation.

## Rationale
ImGui gives immediate-mode UI well suited to tool-like desktop apps, ImPlot provides plotting, and GLFW supplies the windowing and event loop with a small footprint.

## Alternatives Considered
- A retained-mode toolkit such as Qt or GTK
- A custom rendering stack

## Consequences
- Positive: low footprint, fast iteration, full control of the layout contract.
- Negative: custom-drawn UI requires more layout and interaction work than a toolkit.

## Verification
The rendered GUI workflow is exercised through the scripted render path (`IMP-007`, `INFO-044`).

## Review Trigger
None.