---
id: PB-010
title: Explicit parameter-to-source binding
summary: Parameter selection is explicit and bound to the open source or database that provides the series
date: 2026-11-11
status: accepted
layers: [architecture]
state: 02-architecture/components/binding-and-sources.md
artifacts:
  - src/app/selection/binding.cpp
  - src/ui/panels/parameter.hpp
supersedes: []
superseded_by: []
related: []
---

# PB-010: Explicit parameter-to-source binding

## Context
The same parameter name can exist in several files or databases. Users need a direct way to say which parameter comes from which source without guessing.

## Decision
Parameter selection is explicit and bound to the open source or database that provides the series.

## Rationale
Explicit, visible bindings avoid ambiguous selection and keep the source of each parameter inspectable and changeable without reopening files.

## Alternatives Considered
- Automatic source inference from names
- Implicit hidden binding rules

## Consequences
- Positive: discoverable bindings, no guesswork, stable selection state.
- Negative: users manage bindings explicitly rather than being matched automatically.

## Verification
Binding visibility is an acceptance criterion (`INFO-041`) and covered by the parameter-menu IMP (`IMP-009`).

## Review Trigger
None.