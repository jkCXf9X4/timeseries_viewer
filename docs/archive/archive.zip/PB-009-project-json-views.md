---
id: PB-009
title: Saved views as project JSON files
summary: Saved views are project JSON files that restore sources, plots, and expressions
date: 2026-11-11
status: accepted
layers: [product]
state: 01-product/workspace-capabilities.md
artifacts:
  - src/persist/persist.hpp
supersedes: []
superseded_by: []
related: []
---

# PB-009: Saved views as project JSON files

## Context
Users save the current analysis state for later reuse. The saved artifact must be portable, human-readable, and restore sources, plots, and expressions.

## Decision
Saved views are project JSON files that restore sources, plots, and expressions.

## Rationale
JSON is portable and inspectable, and one file per project keeps state user-owned and tied to the local file layout.

## Alternatives Considered
- A binary or database-backed storage format

## Consequences
- Positive: portable, inspectable project files, simple serialization.
- Negative: schema changes must stay backward-readable once saved views exist.

## Verification
Project round-trip is unit tested (`INFO-036`) and save-restore is an acceptance criterion (`INFO-041`).

## Review Trigger
None.