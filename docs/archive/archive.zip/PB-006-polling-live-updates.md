---
id: PB-006
title: Polling for live updates
summary: Live updates use polling rather than platform file watchers
date: 2026-11-11
status: accepted
layers: [architecture]
state: 02-architecture/components/refresh-scheduler.md
artifacts:
  - src/app/source.cpp
supersedes: []
superseded_by: []
related: []
---

# PB-006: Polling for live updates

## Context
Live mode must reload sources that change while the app is open, with predictable behavior and minimal platform-specific code.

## Decision
Live updates use polling rather than platform file watchers.

## Rationale
Polling is simple, portable across Linux environments, and keeps behavior predictable, at the cost of immediacy.

## Alternatives Considered
- Platform file-notification APIs

## Consequences
- Positive: simple and portable, one refresh path on all platforms.
- Negative: less immediate than file notifications; introduces a polling interval.

## Verification
Live-reload workflow is verified in `INFO-039`; watcher-based refresh is tracked as a candidate (`IMP-034`).

## Review Trigger
None.