---
id: PB-012
title: Fixed side panels following the active plot
summary: The parameter browser sits fixed left and the plot inspector fixed right, and both follow the active plot
date: 2026-11-11
status: accepted
layers: [architecture, product]
state: 01-product/ui-description/visual-layout.md
artifacts:
  - src/ui/panels/parameter.hpp
  - src/ui/panels/inspector.hpp
  - src/ui/plot/workspace.hpp
supersedes: []
superseded_by: []
related: []
---

# PB-012: Fixed side panels following the active plot

## Context
Navigation and inspection must stay predictable while the user moves between windows and tabs. Panel position should not depend on window state.

## Decision
The parameter browser is fixed to the left side of the app, the plot inspector is fixed to the right side, and both panels follow the active plot.

## Rationale
Fixed, resizable side panels give a stable workspace while the active-plot coupling keeps edits and inspections unambiguous.

## Alternatives Considered
- Floating or dockable panels
- Static panels tied to a fixed window

## Consequences
- Positive: stable layout, unambiguous target for edits, resizable widths.
- Negative: layout is not user-customizable.

## Verification
Layout integration coverage checks panel position, resizing, and active-plot tracking (`INFO-038`); the layout contract is in `INFO-010`.

## Review Trigger
None.