---
id: PB-002
title: C++23, CMake, and vcpkg implementation stack
summary: The implementation stack is C++23, CMake, and vcpkg as the dependency source of record
date: 2026-11-11
status: accepted
layers: [implementation]
state: 03-implementation/configuration-and-environment.md
artifacts:
  - CMakeLists.txt
  - vcpkg.json
supersedes: []
superseded_by: []
related: []
---

# PB-002: C++23, CMake, and vcpkg implementation stack

## Context
The viewer is a native Linux desktop application with a low-dependency, self-contained footprint. The toolchain must stay modern, reproducible, and able to vendor desktop graphics and UI dependencies.

## Decision
C++23 is the target language level, CMake is the build system, and vcpkg is the dependency source of record.

## Rationale
C++23 fits a desktop app needing fine control and performance. CMake and vcpkg give a reproducible, local dependency flow for a desktop graphics stack.

## Alternatives Considered
- A higher-level framework or language with its own runtime
- Hand-rolled dependency vendoring

## Consequences
- Positive: modern language features, reproducible local builds, explicit dependency set.
- Negative: C++23 requires a current toolchain; vcpkg adds setup steps for contributors.

## Verification
Build configuration is exercised by the project build commands; the environment contract is in `INFO-032`.

## Review Trigger
None.