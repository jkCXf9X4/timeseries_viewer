---
id: PB-004
title: CSV and SQLite initial sources with overridable time selection
summary: CSV and SQLite are the initial source types, with user-overridable time selection
date: 2026-11-11
status: accepted
layers: [product]
state: 01-product/source-capabilities.md
artifacts:
  - src/io/csv/csv.hpp
  - src/io/sqlite/sqlite.hpp
supersedes: []
superseded_by: []
related: []
---

# PB-004: CSV and SQLite initial sources with overridable time selection

## Context
The first release covers common engineering logs and measured data. CSV and SQLite cover the likely local file formats, and time metadata may vary across sources.

## Decision
CSV and SQLite are the initial supported source types, with user-overridable time selection.

## Rationale
CSV is the common export format and SQLite is a common local database; both keep the tool self-contained. Overridable time selection handles metadata variance across sources.

## Alternatives Considered
- Broader source support in the first release
- Fixed time-axis inference without override

## Consequences
- Positive: focused first release, format-agnostic plotting behind adapters.
- Negative: other source types wait for later work.

## Verification
Source browsing consistency and time-selection override are checked in `INFO-041` and unit coverage `INFO-036`.

## Review Trigger
None.