---
id: PB-007
title: Embedded Lua with sol2 bindings for expressions
summary: Derived series use embedded Lua with sol2 bindings
date: 2026-11-11
status: accepted
layers: [architecture]
state: 02-architecture/components/registry-data-expression.md
artifacts:
  - src/expr/expr.hpp
supersedes: []
superseded_by: []
related: []
---

# PB-007: Embedded Lua with sol2 bindings for expressions

## Context
Users define simple derived series such as `a - b` during analysis. The expression mechanism must be simple, deterministic, and sandboxable.

## Decision
Derived series use embedded Lua with `sol2` bindings for expressions.

## Rationale
Lua is a small embeddable scripting language, and sol2 provides safe bindings that keep the expression API narrow and controlled.

## Alternatives Considered
- A hand-written expression parser
- A larger scripting runtime

## Consequences
- Positive: proven expression semantics, sandboxing in one module, narrow API.
- Negative: adds Lua as a runtime dependency for the expression module.

## Verification
Expression evaluation is unit tested (`INFO-036`) and acceptance checks determinism (`INFO-042`).

## Review Trigger
None.