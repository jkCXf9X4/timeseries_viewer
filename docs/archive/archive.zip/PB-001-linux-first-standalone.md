---
id: PB-001
title: Linux-first standalone desktop application
summary: The viewer is a Linux-first, standalone desktop application with local-file workflows
date: 2026-11-11
status: accepted
layers: [intent]
state: 00-intent/constraints.md
artifacts:
  - src/app/main.cpp
  - CMakeLists.txt
supersedes: []
superseded_by: []
related: []
---

# PB-001: Linux-first standalone desktop application

## Context
Engineers inspect time-series data on Linux without a server, cloud workspace, or heavy operating environment. The workflow centers on local files, immediate visual inspection, and reuse of saved analysis state.

## Decision
The viewer is a Linux-first, standalone desktop application with local-file workflows. No backend service is required.

## Rationale
Local desktop use matches the target engineers and keeps the tool lightweight and self-contained. A standalone app avoids server setup and remote dependencies.

## Alternatives Considered
- Web or server-backed analysis environment
- Notebook-style scripting environment

## Consequences
- Positive: immediate local feel, low operating burden, no backend to operate.
- Negative: Linux-first limits cross-platform reach; local-file scope excludes remote and streaming data.

## Verification
Launch and browse flows are checked in manual acceptance (`INFO-040`); deployment expectations are stated in `INFO-046`.

## Review Trigger
None.