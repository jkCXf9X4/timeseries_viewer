---
id: PB-008
title: Left-hand time grid interpolation
summary: Cross-series comparison aligns to the left-hand time grid using interpolation
date: 2026-11-11
status: accepted
layers: [architecture]
state: 02-architecture/components/registry-data-expression.md
artifacts:
  - src/expr/expr.hpp
supersedes: []
superseded_by: []
related: []
---

# PB-008: Left-hand time grid interpolation

## Context
Comparing series from different sources requires aligning them on a common time axis so differences, alignment, and trends are visible in one plot.

## Decision
Cross-series comparison aligns to the left-hand time grid using interpolation.

## Rationale
Interpolation onto one reference grid is simple to explain and matches how users read comparisons in a single plot.

## Alternatives Considered
- Joining on exact timestamp matches
- Interpolating to a computed union grid

## Consequences
- Positive: predictable alignment, straightforward derived-series math.
- Negative: interpolation edge cases need explicit fixtures.

## Verification
Interpolation is unit tested (`INFO-036`) and derived alignment is verified in integration coverage (`INFO-037`).

## Review Trigger
None.