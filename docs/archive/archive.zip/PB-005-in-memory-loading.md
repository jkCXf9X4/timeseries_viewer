---
id: PB-005
title: In-memory loading for medium files
summary: Selected variables load into memory for medium-file operation
date: 2026-11-11
status: accepted
layers: [architecture]
state: 02-architecture/structure.md
artifacts:
  - src/app/cache.cpp
supersedes: []
superseded_by: []
related: []
---

# PB-005: In-memory loading for medium files

## Context
The viewer targets medium-sized datasets and common engineering logs. A simple in-memory model keeps the tool immediate and low-complexity.

## Decision
Selected variables load into memory for medium-file operation.

## Rationale
In-memory loading keeps the model simple, rendering responsive, and avoids streaming complexity for the target dataset size.

## Alternatives Considered
- Streaming or chunked loading from the start
- Full-file eager loading

## Consequences
- Positive: simple model, responsive rendering for medium data.
- Negative: very large archives exceed the comfort zone and need later redesign.

## Verification
Scaling strategy and large-file behavior are tracked by `IMP-006` and `IMP-033`; memory risk is in `INFO-049`.

## Review Trigger
When large-file support becomes a requirement.